using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Return : MonoBehaviour
{
    public void Ret()
    {
        Application.LoadLevel("Start menu");
    }
        

        

}
